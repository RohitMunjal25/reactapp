import React from "react";
import "./ResultPage.css";
import jsPDF from "jspdf";
import html2canvas from "html2canvas";
import { useRef } from "react";
export default function ResultPage({ setPage, file, resultData }) {

  // 🔥 Backend se aane wala REAL report
  const report = resultData?.report || {};
  const reportRef=useRef();

  const fileName = file?.name || "evidence.jpg";

  // 🔎 Verdict mapping backend se
  const verdictLabel = report.final_verdict || "Unknown";

  const verdictColor =
    verdictLabel.includes("Original") ? "#4ade80" :
    verdictLabel.includes("Edited") || report.editing_detected ? "#f87171" :
    "#fbbf24";

  const verdictIcon =
    verdictLabel.includes("Original") ? "✅" :
    verdictLabel.includes("Edited") || report.editing_detected ? "❌" :
    "⚠️";
    const downloadPDF = async () => {
  const element = reportRef.current;

  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
  });

  const imgData = canvas.toDataURL("image/png");

  const pdf = new jsPDF("p", "mm", "a4");
  const imgWidth = 210;
  const pageHeight = 295;
  const imgHeight = (canvas.height * imgWidth) / canvas.width;

  let heightLeft = imgHeight;
  let position = 0;

  pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
  heightLeft -= pageHeight;

  while (heightLeft > 0) {
    position = heightLeft - imgHeight;
    pdf.addPage();
    pdf.addImage(imgData, "PNG", 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
  }

  pdf.save("AI_Evidence_Report.pdf");
};

  return (
    <div ref={reportRef}>

      {/* TOP BAR */}
      <div className="result-topbar">
        <div className="result-file">
          <span style={{ fontSize: 28 }}>🖼️</span>
          <div>
            <div className="result-filename">{fileName}</div>
            <div className="result-filemeta">
              Analyzed · {new Date().toLocaleDateString("en-IN")}
            </div>
          </div>
        </div>

        <span
          className="badge"
          style={{
            background: verdictColor,
            color: "#000",
            fontWeight: 600,
            padding: "6px 16px"
          }}
        >
          {verdictIcon} {verdictLabel}
        </span>
      </div>

      <div className="result-grid">

        {/* LEFT CARD */}
        <div>
          <div className="card score-card">

            <div className="verdict-title" style={{ color: verdictColor }}>
              {verdictIcon} {verdictLabel}
            </div>

            <p className="verdict-desc">
              This report is generated using EXIF & metadata forensic analysis.
            </p>

            {/* QUICK STATUS */}
            <div className="risk-list">

              <div className="risk-item">
                <div className="risk-row-meta">
                  <span>Camera Present</span>
                  <span>{report.camera_present ? "YES 📷" : "NO ❌"}</span>
                </div>
              </div>

              <div className="risk-item">
                <div className="risk-row-meta">
                  <span>Editing Detected</span>
                  <span>{report.editing_detected ? "YES ⚠️" : "NO ✅"}</span>
                </div>
              </div>

              <div className="risk-item">
                <div className="risk-row-meta">
                  <span>GPS Metadata</span>
                  <span>{report.gps_present ? "YES 📍" : "NO ❌"}</span>
                </div>
              </div>

            </div>
          </div>

          {/* METADATA */}
          <div className="card" style={{ marginTop: 16 }}>
  <div className="section-title">Full Forensic Metadata</div>

  {Object.keys(report).length === 0 && (
    <p style={{ fontSize: 12, color: "#64748b" }}>
      No metadata received from backend.
    </p>
  )}

  {Object.entries(report).map(([key, value]) => (
    <div className="meta-row" key={key}>
      <span className="meta-key">{key.replaceAll("_"," ")}</span>
      <span className="meta-val">
        {typeof value === "boolean"
          ? value ? "YES" : "NO"
          : String(value)}
      </span>
    </div>
  ))}
</div>
          <div className="section-title">Detailed Findings</div>

          <div className="finding card">
            <div className="finding-head">
              🎭 <span className="finding-title">Camera Check</span>
            </div>
            <p className="finding-note">
              {report.camera_present
                ? "Camera metadata found in EXIF."
                : "No camera metadata found."}
            </p>
          </div>

          <div className="finding card">
            <div className="finding-head">
              🔬 <span className="finding-title">Editing Analysis</span>
            </div>
            <p className="finding-note">
              {report.editing_detected
                ? "Editing software traces detected."
                : "No editing traces detected."}
            </p>
          </div>

          <div className="finding card">
            <div className="finding-head">
              📍 <span className="finding-title">GPS Data</span>
            </div>
            <p className="finding-note">
              {report.gps_present
                ? "GPS metadata found in file."
                : "No GPS metadata present."}
            </p>
          </div>

          <div className="result-actions">
            <button className="btn btn-blue" onClick={() => setPage("upload")}>
              🔍 Analyze Another
            </button>
            <button className="btn btn-outline" onClick={() => setPage("dashboard")}>
              📊 Dashboard
            </button>
            <button className="btn btn-green" onClick={downloadPDF}>
              📄 Download PDF Report
            </button>
            
          </div>

        </div>
      </div>

    </div>
  );
}