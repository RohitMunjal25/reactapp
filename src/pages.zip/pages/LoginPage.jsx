import React, { useState } from 'react';
import './LoginPage.css';

export default function LoginPage({ onLogin }) {
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [isRegister, setIsRegister] = useState(false);

  // REGISTER USER
  const handleRegister = () => {
    if (!email || !pass) return alert("Fill all fields");

    const users = JSON.parse(localStorage.getItem("users") || "[]");

    const already = users.find(u => u.email === email);
    if (already) return alert("User already exists!");

    users.push({ email, pass, history: [] });
    localStorage.setItem("users", JSON.stringify(users));

    alert("Registered Successfully! Now login.");
    setIsRegister(false);
  };

  // LOGIN USER
  const handleLogin = () => {
    const users = JSON.parse(localStorage.getItem("users") || "[]");
    const user = users.find(u => u.email === email && u.pass === pass);

    if (!user) return alert("Invalid credentials");

    localStorage.setItem("currentUser", email);
    onLogin("user");
  };

  // GUEST LOGIN
  const handleGuest = () => {
    localStorage.removeItem("currentUser");
    onLogin("guest");
  };

  return (
    <div className="login-wrapper">
      <div className="login-left">
        <div className="login-brand">
          <h1>AI Evidence Platform</h1>
          <p>Detect deepfakes & manipulation using AI</p>
        </div>
      </div>

      <div className="login-right">
        <div className="login-box card">
          <h2>{isRegister ? "Register" : "Login"}</h2>

          <div className="input-group">
            <input
              className="input-field"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>

          <div className="input-group">
            <input
              type="password"
              className="input-field"
              placeholder="Password"
              value={pass}
              onChange={e => setPass(e.target.value)}
            />
          </div>

          {isRegister ? (
            <button className="btn btn-blue btn-full" onClick={handleRegister}>
              Register
            </button>
          ) : (
            <button className="btn btn-blue btn-full" onClick={handleLogin}>
              Login
            </button>
          )}

          <div className="login-divider">or</div>

          <button className="btn btn-outline btn-full" onClick={handleGuest}>
            Continue as Guest
          </button>

          <p style={{marginTop:15, cursor:"pointer"}} onClick={()=>setIsRegister(!isRegister)}>
            {isRegister ? "Already have account? Login" : "Create new account"}
          </p>
        </div>
      </div>
    </div>
  );
}